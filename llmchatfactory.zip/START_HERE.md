# 🎯 SIMPLE STARTUP GUIDE

## Your Situation → Your Command

```
┌─────────────────────────────────────────────────────────────┐
│                    WHERE ARE YOU?                            │
└─────────────────────────────────────────────────────────────┘

📦 Just downloaded/extracted files?
   ↓
   ./start.sh                    ← EASIEST, DOES EVERYTHING
   
   
❓ Want guided setup?
   ↓
   ./menu.sh                     ← FULL FEATURED MENU
   
   
🐳 Prefer containers?
   ↓
   docker-compose up -d          ← ISOLATED ENVIRONMENT
   
   
💻 Know what you're doing?
   ↓
   python3 -m venv venv
   source venv/bin/activate
   pip install streamlit requests
   streamlit run llm_model_factory_secure.py
```

---

## 🚀 The Absolute Fastest Start

```bash
# Copy and paste these 2 lines:
chmod +x start.sh
./start.sh
```

That's it! The script will:
- ✅ Install everything automatically
- ✅ Show you a menu
- ✅ Start the application

**Time:** 2-3 minutes

---

## 🔧 What Each Script Does

```
start.sh           ← Start here! Auto-installs, presents options
├── Checks Python
├── Creates virtual environment
├── Installs dependencies  
├── Starts app OR Ollama OR both
└── No configuration needed

menu.sh            ← Full control panel
├── System checks
├── Multiple install methods
├── Configuration wizards
├── Management tools
└── Good for production

quick-install.sh   ← Just setup, doesn't start
├── Creates venv
├── Installs packages
└── You start manually after

test.sh           ← Verify everything works
└── Runs 16+ tests
```

---

## 📱 After Starting

```
┌─────────────────────────────────────────────────────────────┐
│  1. Open browser: http://localhost:8501                     │
│  2. Login: admin / admin123                                 │
│  3. IMMEDIATELY change password!                            │
│  4. Sidebar → Configure model:                              │
│     • API URL: http://localhost:11434/api/generate         │
│     • Model: llama3                                         │
│  5. Try Code Generation tab!                                │
└─────────────────────────────────────────────────────────────┘
```

---

## 🤖 Ollama Quick Setup

### If you selected "Start Ollama" in start.sh:
The script handles everything!

### Manual setup:
```bash
# Install
curl -fsSL https://ollama.com/install.sh | sh

# Download model (pick one)
ollama pull llama3        # 4.7GB - Recommended
ollama pull phi3          # 2.2GB - Fastest
ollama pull mistral       # 4.1GB - Alternative

# Start service
ollama serve

# Verify
ollama list
```

**In the app:** Set API URL to `http://localhost:11434/api/generate`

---

## 🐛 Fix Common Errors

### Error: "ModuleNotFoundError: No module named 'streamlit'"

**You forgot to activate virtual environment!**

```bash
# Fix: Use start.sh (it handles this)
./start.sh

# Or manually:
source venv/bin/activate
pip install streamlit requests
```

### Error: "Address already in use" or "Port 8501"

**Something is already running on that port**

```bash
# Option 1: Kill it
pkill -f streamlit

# Option 2: Use different port  
streamlit run llm_model_factory_secure.py --server.port 8502

# Option 3: Use start.sh advanced menu
./start.sh → Advanced Options → Custom Port
```

### Error: "Permission denied" running ./start.sh

**Script not executable**

```bash
chmod +x start.sh
./start.sh
```

### Can't access http://localhost:8501

**Check if it's actually running:**

```bash
# Is process running?
ps aux | grep streamlit

# Is port open?
netstat -tuln | grep 8501

# Check logs
tail -f logs/app.log
```

---

## 🎨 Visual Decision Tree

```
                    START HERE
                        │
                        ▼
              Do you have Python 3.8+?
                    /     \
                  NO       YES
                  /         \
                 ▼           ▼
        Install Python   Run: ./start.sh
                             │
                             ▼
                      Choose an option:
                    /        |        \
                   /         |         \
                  ▼          ▼          ▼
            Start App   Start     Start All
                       Ollama   (App+Ollama)
                  |         |         |
                  └─────────┴─────────┘
                           │
                           ▼
                   Access localhost:8501
                           │
                           ▼
                      Login & Use!
```

---

## 🏃 Speed Comparison

| Method | Install Time | Start Time | Total |
|--------|--------------|------------|-------|
| ./start.sh | 2 min | Instant | **2 min** ⚡ |
| ./quick-install.sh + manual | 2 min | 10 sec | 2.5 min |
| Manual venv setup | 3 min | 10 sec | 3.5 min |
| Docker | 5 min | 30 sec | 5.5 min |
| Full menu install | 5-10 min | Instant | 5-10 min |

**Winner: ./start.sh** 🏆

---

## ✅ Success Checklist

You'll know it's working when:

- ✅ Terminal shows "You can now view your Streamlit app in your browser"
- ✅ Browser opens to localhost:8501
- ✅ You see login screen
- ✅ Can login with admin/admin123
- ✅ Sidebar shows "Model Control Center"
- ✅ Tabs show: Code Generation, Execution Monitor, etc.

---

## 💾 Save These Commands

```bash
# Start everything
./start.sh

# Stop everything  
pkill -f streamlit
pkill -f ollama

# Restart
pkill -f streamlit && ./start.sh

# Check status
ps aux | grep -E "streamlit|ollama"

# View logs
tail -f logs/app.log

# Run tests
./test.sh
```

---

## 🎓 Next Steps After Starting

1. **Security First**
   - Change admin password
   - Review Security tab
   - Check audit logs

2. **Configure Model**
   - Sidebar → Model Settings
   - Test connection
   - Adjust temperature/context

3. **Try It Out**
   - Code Generation tab
   - Enter simple prompt
   - Review security validation
   - Execute safely

4. **Learn More**
   - README.md - Complete guide
   - SECURITY.md - Security features
   - MENU_GUIDE.md - Full features

---

## 🆘 Still Stuck?

```bash
# Run diagnostics
./test.sh

# Check what's installed
pip list | grep -E "streamlit|requests"

# Check Python version
python3 --version

# Read the logs
tail -50 logs/app.log

# Full documentation
less README.md
```

---

## 🎯 Remember

```
┌─────────────────────────────────────────────────────────┐
│                                                          │
│  The easiest way to start is always:                    │
│                                                          │
│      chmod +x start.sh                                  │
│      ./start.sh                                         │
│                                                          │
│  It handles EVERYTHING automatically!                   │
│                                                          │
└─────────────────────────────────────────────────────────┘
```

---

**Quick Help:**
- 💬 Stuck? Run `./test.sh` to diagnose
- 📚 Need details? Open `README.md`
- 🎮 Want control? Use `./menu.sh`
- ⚡ Want fast? Use `./start.sh`

**Your path: ./start.sh → Select option → Login → Code!**

That's literally it. Enjoy! 🚀
