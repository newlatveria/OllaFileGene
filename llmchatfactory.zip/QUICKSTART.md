# 🚀 QUICK START REFERENCE

## ⚡ Fastest Way to Start (One Command)

```bash
./start.sh
```

This script will:
1. ✅ Check and install all dependencies automatically
2. ✅ Create virtual environment
3. ✅ Install Python packages
4. ✅ Present start options menu
5. ✅ Launch application

---

## 📋 All Start Methods

### Method 1: Interactive Start Script (RECOMMENDED)
```bash
chmod +x start.sh
./start.sh
```
**Features:**
- Auto-installs dependencies
- Start app, Docker, or Ollama
- Multiple configuration options
- No manual setup needed

---

### Method 2: Direct Python Start
```bash
# First time only - install dependencies
python3 -m venv venv
source venv/bin/activate
pip install streamlit requests

# Every time - start application
source venv/bin/activate
python3 -m streamlit run llm_model_factory_secure.py
```

---

### Method 3: Docker Start
```bash
# Start with Docker Compose
docker-compose up -d

# View logs
docker-compose logs -f

# Stop
docker-compose down
```

---

### Method 4: Quick Install + Start
```bash
# One-time setup
./quick-install.sh

# Then start
source venv/bin/activate
streamlit run llm_model_factory_secure.py
```

---

### Method 5: Full Menu System
```bash
./menu.sh
# Navigate: Installation Options → Basic Installation
# Then: Start/Stop Application → Start Application
```

---

## 🤖 Ollama Setup

### Install Ollama
```bash
# Via start script
./start.sh
# Select: 3) Start Ollama Service
# It will offer to install if not found

# Or manually
curl -fsSL https://ollama.com/install.sh | sh
```

### Download Models
```bash
# Via start script
./start.sh
# → 3) Start Ollama Service
# → 1) Download a model

# Or manually
ollama pull llama3        # Recommended
ollama pull mistral       # Alternative
ollama pull codellama     # For coding
ollama pull phi3          # Lightweight
```

### Start Ollama Service
```bash
# Via start script
./start.sh → option 3

# Or manually
ollama serve

# Or as background service
nohup ollama serve > /dev/null 2>&1 &
```

### Verify Ollama
```bash
# Check if running
pgrep -f ollama

# List models
ollama list

# Test API
curl http://localhost:11434/api/tags
```

---

## 🔧 Troubleshooting

### "ModuleNotFoundError: No module named 'streamlit'"

**Solution 1: Use start script (handles everything)**
```bash
./start.sh
```

**Solution 2: Manual install**
```bash
python3 -m venv venv
source venv/bin/activate
pip install streamlit requests
streamlit run llm_model_factory_secure.py
```

**Solution 3: System-wide install (not recommended)**
```bash
pip3 install streamlit requests
python3 -m streamlit run llm_model_factory_secure.py
```

---

### Port 8501 Already in Use

**Solution 1: Kill existing process**
```bash
pkill -f streamlit
# Then start again
```

**Solution 2: Use different port**
```bash
streamlit run llm_model_factory_secure.py --server.port 8502
```

---

### Python Version Issues

**Check version (need 3.8+)**
```bash
python3 --version
```

**Install correct version:**
```bash
# Ubuntu/Debian
sudo apt-get install python3.10

# macOS
brew install python@3.10
```

---

### Ollama Not Working

**Check if running:**
```bash
pgrep -f ollama
```

**Start Ollama:**
```bash
ollama serve
# Or via start.sh → option 3
```

**Reinstall Ollama:**
```bash
curl -fsSL https://ollama.com/install.sh | sh
```

---

## 📱 Access Application

After starting, access at:

- **URL:** http://localhost:8501
- **Username:** admin
- **Password:** admin123
- **⚠️ CHANGE PASSWORD IMMEDIATELY!**

---

## 🎯 Complete Startup Sequence

### For First-Time Users:

```bash
# 1. Make scripts executable
chmod +x *.sh

# 2. Run start script (does everything)
./start.sh

# 3. Select option 4: Start Everything
#    (Installs dependencies, starts Ollama and App)

# 4. Access http://localhost:8501

# 5. Login: admin / admin123

# 6. In sidebar, configure:
#    - API URL: http://localhost:11434/api/generate
#    - Model: llama3 (or your downloaded model)

# 7. Go to Code Generation tab and test!
```

---

## 🔑 Quick Commands

```bash
# Check what's running
pgrep -f streamlit     # Check app
pgrep -f ollama        # Check Ollama
netstat -tuln | grep 8501  # Check port

# Start services
./start.sh             # Interactive
source venv/bin/activate && streamlit run llm_model_factory_secure.py

# Stop services
pkill -f streamlit     # Stop app
pkill -f ollama        # Stop Ollama
docker-compose down    # Stop Docker

# View logs
tail -f logs/app.log        # Application
tail -f logs/audit.log      # Security
docker-compose logs -f      # Docker

# Test installation
./test.sh              # Run all tests
```

---

## 📊 Start Options Comparison

| Method | Setup Time | Best For | Auto-Install |
|--------|-----------|----------|--------------|
| `./start.sh` | 2 min | Everyone | ✅ Yes |
| `./quick-install.sh` | 2 min | Testing | ✅ Yes |
| Manual Python | 5 min | Developers | ❌ No |
| Docker | 10 min | Production | ✅ Partial |
| `./menu.sh` | 5-30 min | Full setup | ✅ Yes |

---

## 💡 Pro Tips

1. **Always use start.sh first** - it handles everything
2. **Activate venv** before manual commands: `source venv/bin/activate`
3. **Download smaller models first** - phi3 is fastest
4. **Check logs** if something fails: `tail -f logs/app.log`
5. **Use Docker** for clean, isolated environment
6. **Run test.sh** to validate installation

---

## 🆘 Still Having Issues?

### Run the diagnostic:
```bash
./test.sh
```

### Check the logs:
```bash
tail -f logs/app.log
tail -f logs/audit.log
tail -f logs/install.log
```

### Get detailed help:
```bash
./menu.sh
# → Documentation → View README
```

---

## 📞 Common Questions

**Q: Do I need Ollama?**  
A: No, but it's recommended for local LLM. You can use external APIs too.

**Q: Can I use GPT/Claude API instead?**  
A: Yes! Just configure API URL in sidebar to your provider's endpoint.

**Q: What's the difference between start.sh and menu.sh?**  
A: start.sh is focused on getting running quickly. menu.sh has full management features.

**Q: Do I need Docker?**  
A: No, Python virtual environment works great. Docker is optional.

**Q: How do I update?**  
A: Re-run `./start.sh` or use `./menu.sh` → Security & Maintenance → Update

---

## ✅ Verification Checklist

After starting, verify:

- [ ] Can access http://localhost:8501
- [ ] Can login with admin/admin123
- [ ] Sidebar shows model settings
- [ ] Code Generation tab loads
- [ ] Security validation works
- [ ] Ollama responds (if installed)

---

**For Complete Documentation:**
- README.md - Full guide
- INSTALL_ALL_METHODS.md - All installation options
- MENU_GUIDE.md - Menu system details
- SECURITY.md - Security features

**Version:** 2.0.0  
**Last Updated:** February 2024
